package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public abstract class Module {
    public final String name;
    private final String id;
    private boolean enabled;

    protected Module(String name) {
        this.name = name;
        this.id = name.toLowerCase().replace(" ", "");
    }

    public boolean isEnabled() {
        return enabled;
    }

    /** Toggle from the menu: also shows ON/OFF above the hotbar. */
    public void toggle() {
        setEnabled(!enabled);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(name + (enabled ? " ON" : " OFF")), true);
        }
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}

    protected void onDisable() {}

    protected String key(String option) {
        return id + "." + option;
    }

    public final void loadConfig() {
        enabled = Config.getBoolean(key("enabled"), false);
        readSettings();
    }

    public final void saveConfig() {
        Config.put(key("enabled"), enabled);
        writeSettings();
    }

    protected void readSettings() {}

    protected void writeSettings() {}

    public abstract void tick(MinecraftClient mc);
}

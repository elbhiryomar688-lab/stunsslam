package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;

/**
 * Throws an ender pearl at the ground below you to survive a lethal fall.
 * It never throws while you are still high up in the sky: it waits until solid ground
 * is within maxGroundDistance blocks below you.
 */
public class PearlClutch extends Module {
    public double minFall = 6.0;            // minimum fall distance before it considers clutching
    public double maxGroundDistance = 12.0; // only throw when ground is this close (not in the sky)
    public boolean onlyWhenLethal = true;   // only when the fall would kill you
    public int cooldownTicks = 40;

    private int wait;

    public PearlClutch() {
        super("Pearl Clutch");
    }

    @Override
    protected void readSettings() {
        minFall = Config.getDouble(key("minFall"), minFall);
        maxGroundDistance = Config.getDouble(key("maxGroundDistance"), maxGroundDistance);
        onlyWhenLethal = Config.getBoolean(key("onlyWhenLethal"), onlyWhenLethal);
        cooldownTicks = Config.getInt(key("cooldownTicks"), cooldownTicks);
    }

    @Override
    protected void writeSettings() {
        Config.put(key("minFall"), minFall);
        Config.put(key("maxGroundDistance"), maxGroundDistance);
        Config.put(key("onlyWhenLethal"), onlyWhenLethal);
        Config.put(key("cooldownTicks"), cooldownTicks);
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (wait > 0) wait--;
        if (!Util.ready(mc) || wait > 0) return;
        ClientPlayerEntity p = mc.player;

        if (!Util.isFalling(p) || p.isGliding()) return;
        if (Util.fallDistance(p) < minFall) return;

        double predicted = Util.predictedFallDamage(p);
        float health = Util.totalHealth(p);
        if (onlyWhenLethal && predicted < health) return;
        // A pearl teleport costs 5 damage itself; useless if it would kill you too.
        if (p.getHealth() <= 5.0f) return;

        BlockHitResult ground = Util.groundBelow(mc, maxGroundDistance);
        if (ground == null) return; // sky / void / water -> don't throw

        int slot = Util.findHotbar(p, s -> s.isOf(Items.ENDER_PEARL));
        if (slot < 0 || Util.onCooldown(p, slot)) return;

        float[] rot = Util.rotationTo(p, ground.getPos());
        if (Util.useItemAt(mc, slot, rot[0], rot[1])) wait = cooldownTicks;
    }
}

package dev.stunslam;

import net.minecraft.client.MinecraftClient;

import java.util.List;

public final class ModuleManager {
    public static final AutoStunSlam STUN_SLAM = new AutoStunSlam();
    public static final AutoMace AUTO_MACE = new AutoMace();
    public static final PearlClutch PEARL_CLUTCH = new PearlClutch();
    public static final WindCharge WIND_CHARGE = new WindCharge();

    private static final List<Module> ALL = List.of(STUN_SLAM, AUTO_MACE, PEARL_CLUTCH, WIND_CHARGE);

    private ModuleManager() {}

    public static List<Module> all() {
        return ALL;
    }

    public static void tick(MinecraftClient mc) {
        for (Module module : ALL) {
            if (!module.isEnabled()) continue;
            try {
                module.tick(mc);
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }
}

package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * While you fall onto a player, holds the mace and smashes them as soon as they are in reach.
 */
public class AutoMace extends Module {
    public double reach = 3.0;
    public double prepareRange = 7.0;   // start holding the mace when a target is this close
    public double minFall = 1.5;        // mace smash needs more than 1.5 blocks of fall
    public float minCooldown = 0.9f;    // attack cooldown required before swinging
    public boolean switchBack = true;

    private int prevSlot = -1;

    public AutoMace() {
        super("Auto Mace");
    }

    @Override
    protected void readSettings() {
        reach = Config.getDouble(key("reach"), reach);
        prepareRange = Config.getDouble(key("prepareRange"), prepareRange);
        minFall = Config.getDouble(key("minFall"), minFall);
        minCooldown = Config.getFloat(key("minCooldown"), minCooldown);
        switchBack = Config.getBoolean(key("switchBack"), switchBack);
    }

    @Override
    protected void writeSettings() {
        Config.put(key("reach"), reach);
        Config.put(key("prepareRange"), prepareRange);
        Config.put(key("minFall"), minFall);
        Config.put(key("minCooldown"), minCooldown);
        Config.put(key("switchBack"), switchBack);
    }

    @Override
    protected void onDisable() {
        restore(MinecraftClient.getInstance().player);
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (!Util.ready(mc)) {
            prevSlot = -1;
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (ModuleManager.STUN_SLAM.busy()) return;

        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        boolean falling = Util.isFalling(p) && Util.fallDistance(p) >= minFall;
        PlayerEntity target = (mace >= 0 && falling) ? Util.nearestPlayer(mc, prepareRange) : null;

        if (target == null) {
            restore(p);
            return;
        }
        // Players holding a shield are handled by Auto Stun Slam when it is enabled.
        if (ModuleManager.STUN_SLAM.isEnabled() && target.isBlocking()) return;

        if (prevSlot == -1 && Util.selectedSlot(p) != mace) prevSlot = Util.selectedSlot(p);
        Util.select(p, mace);

        if (Util.eyeDistance(p, target) <= reach && p.getAttackCooldownProgress(0.5f) >= minCooldown) {
            Util.attack(mc, target);
        }
    }

    private void restore(ClientPlayerEntity p) {
        if (p != null && switchBack && prevSlot != -1) Util.select(p, prevSlot);
        prevSlot = -1;
    }
}

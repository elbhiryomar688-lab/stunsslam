package dev.stunslam;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Simple settings file: .minecraft/config/stunslam.properties
 * Edit it with any text editor while the game is closed. Delete it to reset to defaults.
 */
public final class Config {
    private static final Properties PROPS = new Properties();

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("stunslam.properties");
    }

    public static void load() {
        try (InputStream in = Files.newInputStream(file())) {
            PROPS.load(in);
        } catch (NoSuchFileException ignored) {
            // first run: defaults
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Module module : ModuleManager.all()) module.loadConfig();
        save(); // writes the file with every option so it is easy to edit
    }

    public static void save() {
        for (Module module : ModuleManager.all()) module.saveConfig();
        try (OutputStream out = Files.newOutputStream(file())) {
            PROPS.store(out, "StunSlam settings (true/false for on/off, numbers for ranges). Edit while the game is closed.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void put(String key, Object value) {
        PROPS.setProperty(key, String.valueOf(value));
    }

    public static boolean getBoolean(String key, boolean def) {
        String v = PROPS.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    public static double getDouble(String key, double def) {
        try {
            String v = PROPS.getProperty(key);
            return v == null ? def : Double.parseDouble(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    public static float getFloat(String key, float def) {
        return (float) getDouble(key, def);
    }

    public static int getInt(String key, int def) {
        return (int) Math.round(getDouble(key, def));
    }
}

package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Stun slam: while falling onto a player who is blocking with a shield,
 * hit them with an axe to disable the shield, then smash them with the mace.
 * Optionally launches you into the air first with a wind charge.
 *
 * Needs an axe and a mace in the hotbar (and a wind charge for auto launch).
 */
public class AutoStunSlam extends Module {
    public double reach = 3.0;
    public double prepareRange = 7.0;
    public double launchRange = 6.0;     // when on the ground, launch if a shielding player is this close
    public double minFall = 1.5;
    public float axeCooldown = 0.9f;     // axe needs a strong hit to break the shield
    public int maceWaitTicks = 4;        // max ticks to wait for the mace cooldown after the axe hit
    public boolean autoLaunch = true;

    private enum Stage { IDLE, STUN, SLAM }

    private Stage stage = Stage.IDLE;
    private PlayerEntity target;
    private int ticks;
    private int slamWait;
    private int launchWait;
    private int prevSlot = -1;

    public AutoStunSlam() {
        super("Auto Stun Slam");
    }

    public boolean busy() {
        return stage != Stage.IDLE;
    }

    @Override
    protected void readSettings() {
        reach = Config.getDouble(key("reach"), reach);
        prepareRange = Config.getDouble(key("prepareRange"), prepareRange);
        launchRange = Config.getDouble(key("launchRange"), launchRange);
        minFall = Config.getDouble(key("minFall"), minFall);
        axeCooldown = Config.getFloat(key("axeCooldown"), axeCooldown);
        maceWaitTicks = Config.getInt(key("maceWaitTicks"), maceWaitTicks);
        autoLaunch = Config.getBoolean(key("autoLaunch"), autoLaunch);
    }

    @Override
    protected void writeSettings() {
        Config.put(key("reach"), reach);
        Config.put(key("prepareRange"), prepareRange);
        Config.put(key("launchRange"), launchRange);
        Config.put(key("minFall"), minFall);
        Config.put(key("axeCooldown"), axeCooldown);
        Config.put(key("maceWaitTicks"), maceWaitTicks);
        Config.put(key("autoLaunch"), autoLaunch);
    }

    @Override
    protected void onDisable() {
        reset(MinecraftClient.getInstance().player);
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (!Util.ready(mc)) {
            reset(null);
            return;
        }
        ClientPlayerEntity p = mc.player;
        if (launchWait > 0) launchWait--;

        int axe = Util.findHotbar(p, Util::isAxe);
        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        if (axe < 0 || mace < 0) {
            reset(p);
            return;
        }

        switch (stage) {
            case IDLE -> idle(mc, p);
            case STUN -> stun(mc, p, axe);
            case SLAM -> slam(mc, p, mace);
        }
    }

    private void idle(MinecraftClient mc, ClientPlayerEntity p) {
        double range = (autoLaunch && p.isOnGround()) ? launchRange : prepareRange;
        PlayerEntity t = Util.nearestPlayer(mc, range, PlayerEntity::isBlocking);
        if (t == null) return;

        if (p.isOnGround()) {
            if (autoLaunch && launchWait == 0 && WindCharge.launch(mc)) launchWait = 20;
            return;
        }
        if (Util.isFalling(p) && Util.fallDistance(p) >= minFall) {
            target = t;
            stage = Stage.STUN;
            ticks = 0;
            prevSlot = Util.selectedSlot(p);
        }
    }

    private void stun(MinecraftClient mc, ClientPlayerEntity p, int axe) {
        ticks++;
        if (invalid(p)) {
            reset(p);
            return;
        }
        Util.select(p, axe);
        if (!target.isBlocking()) {
            stage = Stage.SLAM;
            slamWait = 0;
            return;
        }
        if (Util.eyeDistance(p, target) <= reach && p.getAttackCooldownProgress(0.5f) >= axeCooldown) {
            Util.attack(mc, target);
            stage = Stage.SLAM;
            slamWait = 0;
        }
    }

    private void slam(MinecraftClient mc, ClientPlayerEntity p, int mace) {
        ticks++;
        slamWait++;
        if (invalid(p)) {
            reset(p);
            return;
        }
        Util.select(p, mace);
        boolean cooldownOk = p.getAttackCooldownProgress(0.5f) >= 0.9f;
        if (Util.eyeDistance(p, target) <= reach && (cooldownOk || slamWait >= maceWaitTicks)) {
            Util.attack(mc, target);
            reset(p);
        }
    }

    private boolean invalid(ClientPlayerEntity p) {
        return target == null
                || !target.isAlive()
                || ticks > 80
                || p.isOnGround()
                || p.isTouchingWater()
                || Util.eyeDistance(p, target) > prepareRange + 2.0;
    }

    private void reset(ClientPlayerEntity p) {
        if (p != null && prevSlot != -1) Util.select(p, prevSlot);
        stage = Stage.IDLE;
        target = null;
        prevSlot = -1;
        ticks = 0;
    }
}

package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;

/**
 * Wind Charge helper.
 *  - Clutch: throws a wind charge straight down right before you hit the ground to cancel a lethal fall.
 *  - launch(): used by Auto Stun Slam to shoot yourself into the air.
 */
public class WindCharge extends Module {
    public double minFall = 6.0;            // only consider clutching after falling this far
    public boolean onlyWhenLethal = true;   // only when the fall would kill you
    public double triggerHeight = 2.5;      // blocks above ground when we throw
    public int cooldownTicks = 10;

    private int wait;

    public WindCharge() {
        super("Wind Charge");
    }

    @Override
    protected void readSettings() {
        minFall = Config.getDouble(key("minFall"), minFall);
        onlyWhenLethal = Config.getBoolean(key("onlyWhenLethal"), onlyWhenLethal);
        triggerHeight = Config.getDouble(key("triggerHeight"), triggerHeight);
        cooldownTicks = Config.getInt(key("cooldownTicks"), cooldownTicks);
    }

    @Override
    protected void writeSettings() {
        Config.put(key("minFall"), minFall);
        Config.put(key("onlyWhenLethal"), onlyWhenLethal);
        Config.put(key("triggerHeight"), triggerHeight);
        Config.put(key("cooldownTicks"), cooldownTicks);
    }

    @Override
    public void tick(MinecraftClient mc) {
        if (wait > 0) wait--;
        if (!Util.ready(mc) || wait > 0) return;
        ClientPlayerEntity p = mc.player;

        if (!Util.isFalling(p)) return;
        if (Util.fallDistance(p) < minFall) return;
        if (onlyWhenLethal && Util.predictedFallDamage(p) < Util.totalHealth(p)) return;

        BlockHitResult ground = Util.groundBelow(mc, triggerHeight);
        if (ground == null) return; // not close to ground yet (or water below) -> don't throw in the sky

        if (launch(mc)) wait = cooldownTicks;
    }

    /** Throws a wind charge straight down. Returns true if it was thrown. */
    public static boolean launch(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        int slot = Util.findHotbar(p, s -> s.isOf(Items.WIND_CHARGE));
        if (slot < 0 || Util.onCooldown(p, slot)) return false;
        return Util.useItemAt(mc, slot, p.getYaw(), 90.0f);
    }
}

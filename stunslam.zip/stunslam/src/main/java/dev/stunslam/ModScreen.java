package dev.stunslam;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ModScreen extends Screen {
    public ModScreen() {
        super(Text.literal("StunSlam"));
    }

    @Override
    protected void init() {
        int y = this.height / 2 - 40;
        for (Module module : ModuleManager.all()) {
            addDrawableChild(ButtonWidget.builder(label(module), button -> {
                module.toggle();
                button.setMessage(label(module));
            }).dimensions(this.width / 2 - 90, y, 180, 20).build());
            y += 24;
        }
    }

    private static Text label(Module module) {
        return Text.literal(module.name + ": " + (module.isEnabled() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 64, 0xFFFFFFFF);
    }

    @Override
    public void removed() {
        Config.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

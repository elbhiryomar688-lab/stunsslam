package dev.stunslam;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.function.Predicate;

public final class Util {
    private Util() {}

    public static boolean ready(MinecraftClient mc) {
        return mc.player != null && mc.world != null && mc.interactionManager != null && mc.currentScreen == null;
    }

    public static boolean isAxe(ItemStack stack) {
        return stack.isIn(ItemTags.AXES);
    }

    /** Returns hotbar slot (0-8) of the first matching stack, or -1. */
    public static int findHotbar(ClientPlayerEntity p, Predicate<ItemStack> filter) {
        for (int i = 0; i < 9; i++) {
            if (filter.test(p.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    public static int selectedSlot(ClientPlayerEntity p) {
        return p.getInventory().getSelectedSlot();
    }

    public static void select(ClientPlayerEntity p, int slot) {
        if (slot >= 0 && slot <= 8 && selectedSlot(p) != slot) {
            p.getInventory().setSelectedSlot(slot);
        }
    }

    public static double fallDistance(ClientPlayerEntity p) {
        double d = p.fallDistance;
        return d;
    }

    public static boolean isFalling(ClientPlayerEntity p) {
        return !p.isOnGround() && !p.isTouchingWater() && !p.isClimbing() && p.getVelocity().y < 0;
    }

    /** Distance from the player's eyes to the closest point of the entity's hitbox. */
    public static double eyeDistance(ClientPlayerEntity p, Entity e) {
        Box box = e.getBoundingBox();
        Vec3d eye = p.getEyePos();
        double dx = Math.max(Math.max(box.minX - eye.x, 0), eye.x - box.maxX);
        double dy = Math.max(Math.max(box.minY - eye.y, 0), eye.y - box.maxY);
        double dz = Math.max(Math.max(box.minZ - eye.z, 0), eye.z - box.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range) {
        return nearestPlayer(mc, range, other -> true);
    }

    public static PlayerEntity nearestPlayer(MinecraftClient mc, double range, Predicate<PlayerEntity> filter) {
        ClientPlayerEntity self = mc.player;
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == self || !other.isAlive() || other.isSpectator()) continue;
            if (!filter.test(other)) continue;
            double d = eyeDistance(self, other);
            if (d <= range && d < bestDist) {
                bestDist = d;
                best = other;
            }
        }
        return best;
    }

    public static void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    public static boolean onCooldown(ClientPlayerEntity p, int slot) {
        return p.getItemCooldownManager().isCoolingDown(p.getInventory().getStack(slot));
    }

    /**
     * Uses the item in the given hotbar slot while looking at yaw/pitch for that single use,
     * then restores the previous rotation and selected slot.
     */
    public static boolean useItemAt(MinecraftClient mc, int slot, float yaw, float pitch) {
        ClientPlayerEntity p = mc.player;
        int prevSlot = selectedSlot(p);
        float prevYaw = p.getYaw();
        float prevPitch = p.getPitch();

        select(p, slot);
        p.setYaw(yaw);
        p.setPitch(pitch);
        ActionResult result = mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        boolean ok = result.isAccepted();
        if (ok) p.swingHand(Hand.MAIN_HAND);
        p.setYaw(prevYaw);
        p.setPitch(prevPitch);
        select(p, prevSlot);
        return ok;
    }

    public static float[] rotationTo(ClientPlayerEntity p, Vec3d target) {
        Vec3d eye = p.getEyePos();
        double dx = target.x - eye.x;
        double dy = target.y - eye.y;
        double dz = target.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, horizontal) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    /** Solid ground below the player within maxDist blocks, or null (void / water / too far). */
    public static BlockHitResult groundBelow(MinecraftClient mc, double maxDist) {
        ClientPlayerEntity p = mc.player;
        Vec3d start = new Vec3d(p.getX(), p.getY(), p.getZ());
        Vec3d end = start.add(0, -maxDist, 0);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.ANY, p));
        if (hit.getType() != HitResult.Type.BLOCK) return null;
        if (!mc.world.getFluidState(hit.getBlockPos()).isEmpty()) return null; // water breaks the fall anyway
        return hit;
    }

    /** Vanilla fall damage estimate (ignores Feather Falling, potions, etc.). */
    public static double predictedFallDamage(ClientPlayerEntity p) {
        return Math.max(0.0, fallDistance(p) - 3.0);
    }

    public static float totalHealth(ClientPlayerEntity p) {
        return p.getHealth() + p.getAbsorptionAmount();
    }
}
